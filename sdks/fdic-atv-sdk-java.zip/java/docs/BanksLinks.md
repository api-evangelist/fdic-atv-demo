
# BanksLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | **String** | The full URL to reference this object. |  [optional]



