# BanksApi

All URIs are relative to *https://atv1.cfapps.io/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**banksBankIdGet**](BanksApi.md#banksBankIdGet) | **GET** /banks/{bank_id} | Get Bank
[**banksGet**](BanksApi.md#banksGet) | **GET** /banks | Get Banks


<a name="banksBankIdGet"></a>
# **banksBankIdGet**
> Bank banksBankIdGet(bankId)

Get Bank

Returns an individual bank..

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BanksApi;


BanksApi apiInstance = new BanksApi();
Integer bankId = 56; // Integer | The unique id for the bank.
try {
    Bank result = apiInstance.banksBankIdGet(bankId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BanksApi#banksBankIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bankId** | **Integer**| The unique id for the bank. |

### Return type

[**Bank**](Bank.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="banksGet"></a>
# **banksGet**
> Banks banksGet()

Get Banks

Returns a list of banks

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BanksApi;


BanksApi apiInstance = new BanksApi();
try {
    Banks result = apiInstance.banksGet();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BanksApi#banksGet");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Banks**](Banks.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

