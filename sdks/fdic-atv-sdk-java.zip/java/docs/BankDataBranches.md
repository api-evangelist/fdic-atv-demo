
# BankDataBranches

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offnum** | **Integer** | The Offnum Schema |  [optional]
**name** | **String** | The Name Schema |  [optional]
**offname** | **String** | The Offname Schema |  [optional]
**type** | **String** | The Type Schema |  [optional]



