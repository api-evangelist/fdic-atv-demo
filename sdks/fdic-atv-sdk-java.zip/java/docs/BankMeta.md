
# BankMeta

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | The Type Schema |  [optional]
**params** | [**BankMetaParams**](BankMetaParams.md) |  |  [optional]



