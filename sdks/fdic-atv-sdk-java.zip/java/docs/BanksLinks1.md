
# BanksLinks1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | **String** | The Self Schema |  [optional]



