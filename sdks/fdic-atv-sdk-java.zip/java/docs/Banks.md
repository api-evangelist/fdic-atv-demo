
# Banks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**BanksMeta**](BanksMeta.md) |  |  [optional]
**links** | [**BanksLinks**](BanksLinks.md) |  |  [optional]
**data** | [**List&lt;BanksData&gt;**](BanksData.md) |  |  [optional]



