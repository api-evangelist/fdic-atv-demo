
# BanksData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **String** | The Address Schema |  [optional]
**city** | **String** | The City Schema |  [optional]
**cbsaMetroName** | **String** | The Cbsa_metro_name Schema |  [optional]
**name** | **String** | The Name Schema |  [optional]
**namehcr** | **String** | The Namehcr Schema |  [optional]
**score** | **Integer** | The Score Schema |  [optional]
**id** | **String** | The Id Schema |  [optional]
**type** | **String** | The Type Schema |  [optional]
**links** | [**BanksLinks1**](BanksLinks1.md) |  |  [optional]



