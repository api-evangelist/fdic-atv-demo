
# Bank

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**BankMeta**](BankMeta.md) |  |  [optional]
**links** | [**BanksLinks1**](BanksLinks1.md) |  |  [optional]
**data** | [**BankData**](BankData.md) |  |  [optional]



