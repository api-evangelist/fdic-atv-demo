# BanksData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **string** | The Address Schema | [optional] [default to '']
**city** | **string** | The City Schema | [optional] [default to '']
**cbsa_metro_name** | **string** | The Cbsa_metro_name Schema | [optional] [default to '']
**name** | **string** | The Name Schema | [optional] [default to '']
**namehcr** | **string** | The Namehcr Schema | [optional] [default to '']
**score** | **int** | The Score Schema | [optional] 
**id** | **string** | The Id Schema | [optional] [default to '']
**type** | **string** | The Type Schema | [optional] [default to '']
**links** | [**\Swagger\Client\Model\BanksLinks1**](BanksLinks1.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


