# BankDataBranches

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offnum** | **int** | The Offnum Schema | [optional] 
**name** | **string** | The Name Schema | [optional] [default to '']
**offname** | **string** | The Offname Schema | [optional] [default to '']
**type** | **string** | The Type Schema | [optional] [default to '']

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


