# Banks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**\Swagger\Client\Model\BanksMeta**](BanksMeta.md) |  | [optional] 
**links** | [**\Swagger\Client\Model\BanksLinks**](BanksLinks.md) |  | [optional] 
**data** | [**\Swagger\Client\Model\BanksData[]**](BanksData.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


