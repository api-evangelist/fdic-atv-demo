# BankDataSdiData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**p9reres** | **int** | The P9reres Schema | [optional] 
**lnremult** | **int** | The Lnremult Schema | [optional] 
**offdom** | **int** | The Offdom Schema | [optional] 
**lnrecnfm** | **int** | The Lnrecnfm Schema | [optional] 
**reportdate** | **string** | The Reportdate Schema | [optional] [default to '']
**lnre** | **int** | The Lnre Schema | [optional] 
**lnreres** | **int** | The Lnreres Schema | [optional] 
**cert** | **int** | The Cert Schema | [optional] 
**asset** | **int** | The Asset Schema | [optional] 
**p3reres** | **int** | The P3reres Schema | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


