# Bank

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**\Swagger\Client\Model\BankMeta**](BankMeta.md) |  | [optional] 
**links** | [**\Swagger\Client\Model\BanksLinks1**](BanksLinks1.md) |  | [optional] 
**data** | [**\Swagger\Client\Model\BankData**](BankData.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


