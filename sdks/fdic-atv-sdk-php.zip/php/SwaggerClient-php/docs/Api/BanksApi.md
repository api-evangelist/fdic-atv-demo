# Swagger\Client\BanksApi

All URIs are relative to *https://atv1.cfapps.io/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**banksBankIdGet**](BanksApi.md#banksBankIdGet) | **GET** /banks/{bank_id} | Get Bank
[**banksGet**](BanksApi.md#banksGet) | **GET** /banks | Get Banks


# **banksBankIdGet**
> \Swagger\Client\Model\Bank banksBankIdGet($bank_id)

Get Bank

Returns an individual bank..

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\BanksApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$bank_id = 56; // int | The unique id for the bank.

try {
    $result = $apiInstance->banksBankIdGet($bank_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BanksApi->banksBankIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bank_id** | **int**| The unique id for the bank. |

### Return type

[**\Swagger\Client\Model\Bank**](../Model/Bank.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **banksGet**
> \Swagger\Client\Model\Banks banksGet()

Get Banks

Returns a list of banks

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\BanksApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->banksGet();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BanksApi->banksGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\Banks**](../Model/Banks.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

