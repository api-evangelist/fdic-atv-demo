# Banks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Meta** | [***BanksMeta**](banks_meta.md) |  | [optional] [default to null]
**Links** | [***BanksLinks**](banks_links.md) |  | [optional] [default to null]
**Data** | [**[]BanksData**](banks_data.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


