# BanksData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address** | **string** | The Address Schema | [optional] [default to null]
**City** | **string** | The City Schema | [optional] [default to null]
**CbsaMetroName** | **string** | The Cbsa_metro_name Schema | [optional] [default to null]
**Name** | **string** | The Name Schema | [optional] [default to null]
**Namehcr** | **string** | The Namehcr Schema | [optional] [default to null]
**Score** | **int32** | The Score Schema | [optional] [default to null]
**Id** | **string** | The Id Schema | [optional] [default to null]
**Type_** | **string** | The Type Schema | [optional] [default to null]
**Links** | [***BanksLinks1**](banks_links_1.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


