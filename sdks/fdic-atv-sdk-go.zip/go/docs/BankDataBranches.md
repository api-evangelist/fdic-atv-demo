# BankDataBranches

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Offnum** | **int32** | The Offnum Schema | [optional] [default to null]
**Name** | **string** | The Name Schema | [optional] [default to null]
**Offname** | **string** | The Offname Schema | [optional] [default to null]
**Type_** | **string** | The Type Schema | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


