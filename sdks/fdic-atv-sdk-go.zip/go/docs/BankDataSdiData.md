# BankDataSdiData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**P9reres** | **int32** | The P9reres Schema | [optional] [default to null]
**Lnremult** | **int32** | The Lnremult Schema | [optional] [default to null]
**Offdom** | **int32** | The Offdom Schema | [optional] [default to null]
**Lnrecnfm** | **int32** | The Lnrecnfm Schema | [optional] [default to null]
**Reportdate** | **string** | The Reportdate Schema | [optional] [default to null]
**Lnre** | **int32** | The Lnre Schema | [optional] [default to null]
**Lnreres** | **int32** | The Lnreres Schema | [optional] [default to null]
**Cert** | **int32** | The Cert Schema | [optional] [default to null]
**Asset** | **int32** | The Asset Schema | [optional] [default to null]
**P3reres** | **int32** | The P3reres Schema | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


