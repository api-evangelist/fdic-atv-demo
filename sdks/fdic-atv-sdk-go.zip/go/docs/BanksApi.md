# \BanksApi

All URIs are relative to *https://atv1.cfapps.io/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**BanksBankIdGet**](BanksApi.md#BanksBankIdGet) | **Get** /banks/{bank_id} | Get Bank
[**BanksGet**](BanksApi.md#BanksGet) | **Get** /banks | Get Banks


# **BanksBankIdGet**
> Bank BanksBankIdGet(ctx, bankId)
Get Bank

Returns an individual bank..

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **bankId** | **int32**| The unique id for the bank. | 

### Return type

[**Bank**](bank.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **BanksGet**
> Banks BanksGet(ctx, )
Get Banks

Returns a list of banks

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**Banks**](banks.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

