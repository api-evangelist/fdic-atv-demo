# Bank

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Meta** | [***BankMeta**](bank_meta.md) |  | [optional] [default to null]
**Links** | [***BanksLinks1**](banks_links_1.md) |  | [optional] [default to null]
**Data** | [***BankData**](bank_data.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


