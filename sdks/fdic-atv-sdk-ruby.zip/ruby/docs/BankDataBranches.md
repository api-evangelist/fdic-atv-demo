# SwaggerClient::BankDataBranches

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offnum** | **Integer** | The Offnum Schema | [optional] 
**name** | **String** | The Name Schema | [optional] [default to &quot;&quot;]
**offname** | **String** | The Offname Schema | [optional] [default to &quot;&quot;]
**type** | **String** | The Type Schema | [optional] [default to &quot;&quot;]


