# SwaggerClient::BanksLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_self** | **String** | The full URL to reference this object. | [optional] 


