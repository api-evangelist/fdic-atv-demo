# SwaggerClient::BankDataSdiData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**p9reres** | **Integer** | The P9reres Schema | [optional] 
**lnremult** | **Integer** | The Lnremult Schema | [optional] 
**offdom** | **Integer** | The Offdom Schema | [optional] 
**lnrecnfm** | **Integer** | The Lnrecnfm Schema | [optional] 
**reportdate** | **String** | The Reportdate Schema | [optional] [default to &quot;&quot;]
**lnre** | **Integer** | The Lnre Schema | [optional] 
**lnreres** | **Integer** | The Lnreres Schema | [optional] 
**cert** | **Integer** | The Cert Schema | [optional] 
**asset** | **Integer** | The Asset Schema | [optional] 
**p3reres** | **Integer** | The P3reres Schema | [optional] 


