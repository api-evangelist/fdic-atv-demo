# SwaggerClient::BanksData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **String** | The Address Schema | [optional] [default to &quot;&quot;]
**city** | **String** | The City Schema | [optional] [default to &quot;&quot;]
**cbsa_metro_name** | **String** | The Cbsa_metro_name Schema | [optional] [default to &quot;&quot;]
**name** | **String** | The Name Schema | [optional] [default to &quot;&quot;]
**namehcr** | **String** | The Namehcr Schema | [optional] [default to &quot;&quot;]
**score** | **Integer** | The Score Schema | [optional] 
**id** | **String** | The Id Schema | [optional] [default to &quot;&quot;]
**type** | **String** | The Type Schema | [optional] [default to &quot;&quot;]
**links** | [**BanksLinks1**](BanksLinks1.md) |  | [optional] 


