# SwaggerClient::BanksLinks1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_self** | **String** | The Self Schema | [optional] [default to &quot;&quot;]


