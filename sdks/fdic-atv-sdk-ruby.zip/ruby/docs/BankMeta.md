# SwaggerClient::BankMeta

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | The Type Schema | [optional] [default to &quot;&quot;]
**params** | [**BankMetaParams**](BankMetaParams.md) |  | [optional] 


