# SwaggerClient::Banks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**BanksMeta**](BanksMeta.md) |  | [optional] 
**links** | [**BanksLinks**](BanksLinks.md) |  | [optional] 
**data** | [**Array&lt;BanksData&gt;**](BanksData.md) |  | [optional] 


