# SwaggerClient::BanksApi

All URIs are relative to *https://atv1.cfapps.io/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**banks_bank_id_get**](BanksApi.md#banks_bank_id_get) | **GET** /banks/{bank_id} | Get Bank
[**banks_get**](BanksApi.md#banks_get) | **GET** /banks | Get Banks


# **banks_bank_id_get**
> Bank banks_bank_id_get(bank_id)

Get Bank

Returns an individual bank..

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::BanksApi.new

bank_id = 56 # Integer | The unique id for the bank.


begin
  #Get Bank
  result = api_instance.banks_bank_id_get(bank_id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling BanksApi->banks_bank_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bank_id** | **Integer**| The unique id for the bank. | 

### Return type

[**Bank**](Bank.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json



# **banks_get**
> Banks banks_get

Get Banks

Returns a list of banks

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::BanksApi.new

begin
  #Get Banks
  result = api_instance.banks_get
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling BanksApi->banks_get: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Banks**](Banks.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json



