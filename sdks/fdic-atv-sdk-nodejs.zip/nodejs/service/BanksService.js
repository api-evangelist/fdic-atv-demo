'use strict';


/**
 * Get Bank
 * Returns an individual bank..
 *
 * bank_id Integer The unique id for the bank.
 * returns bank
 **/
exports.banksBank_idGET = function(bank_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "data" : {
    "cfpbflag" : 0,
    "rssdhcr" : 6,
    "specgrp" : 1,
    "charter" : 5,
    "county" : "county",
    "cfpbenddte" : "cfpbenddte",
    "cert" : 5,
    "fdicdbs" : 2,
    "type" : "type",
    "dep" : "dep",
    "stnum" : 7,
    "cbsa_metro" : 9,
    "procdate" : "procdate",
    "inactive" : 3,
    "te04n529" : "te04n529",
    "te04n528" : "te04n528",
    "roaq" : 2.027123023002321833274663731572218239307403564453125,
    "insagnt1" : "insagnt1",
    "id" : "id",
    "zip" : 4,
    "insbif" : 7,
    "stchrtr" : 1,
    "active" : 1,
    "stalp" : "stalp",
    "te06n529" : "te06n529",
    "insdate" : "insdate",
    "fdicsupv" : "fdicsupv",
    "instcrcd" : 1,
    "offdom" : 6,
    "city" : "city",
    "qbprcoml" : 7,
    "otsregnm" : "otsregnm",
    "occdist" : 1,
    "fedchrtr" : 4,
    "repdte" : "repdte",
    "certcons" : 5,
    "netinc" : "netinc",
    "denovo" : 9,
    "cityhcr" : "cityhcr",
    "inscoml" : 9,
    "cb" : 6,
    "subchaps" : 8,
    "roaptx" : 9.0183481860707832566959041287191212177276611328125,
    "address" : "address",
    "cbsa_micro_flg" : 6,
    "iba" : 3,
    "estymd" : "estymd",
    "fed_rssd" : 6,
    "uninum" : 1,
    "cbsa_div_no" : 2,
    "inssaif" : 6,
    "ultcert" : 6,
    "te02n529" : "te02n529",
    "te02n528" : "te02n528",
    "msa" : "msa",
    "asset" : "asset",
    "form31" : 5,
    "fldoff" : "fldoff",
    "changec3" : 6,
    "changec4" : 3,
    "changec5" : 3,
    "oakar" : 7,
    "fed" : 0,
    "hctmult" : 7,
    "te03n529" : "te03n529",
    "te03n528" : "te03n528",
    "msa_no" : 6,
    "offices" : 0,
    "bkclass" : "bkclass",
    "sasser" : 4,
    "te01n528" : "te01n528",
    "stalphcr" : "stalphcr",
    "cbsa_no" : 8,
    "roeq" : 7.7403518187411730622216055053286254405975341796875,
    "instag" : 3,
    "otsdist" : 3,
    "cmsa_no" : 7,
    "insdif" : 5,
    "te05n529" : "te05n529",
    "cbsa_metro_flg" : 3,
    "netincq" : "netincq",
    "eq" : "eq",
    "branches" : [ {
      "offnum" : 4,
      "name" : "name",
      "offname" : "offname",
      "type" : "type"
    }, {
      "offnum" : 4,
      "name" : "name",
      "offname" : "offname",
      "type" : "type"
    } ],
    "mutual" : 0,
    "webaddr" : "webaddr",
    "name" : "name",
    "regagnt" : "regagnt",
    "roaptxq" : 6.6284642750877420525057459599338471889495849609375,
    "specgrpn" : "specgrpn",
    "depdom" : "depdom",
    "effdate" : "effdate",
    "endefymd" : "endefymd",
    "changec1" : 4,
    "csa_no" : 1,
    "stname" : "stname",
    "changec2" : 4,
    "trust" : 7,
    "stmult" : 9,
    "tract" : 0,
    "cbsa" : "cbsa",
    "roa" : 9.7029638000235660655334868351928889751434326171875,
    "clcode" : 0,
    "inssave" : 7,
    "newcert" : 5,
    "roe" : 4.863159081028840091676102019846439361572265625,
    "docket" : 6,
    "offfor" : 8,
    "offoa" : 4,
    "fdicregn" : "fdicregn",
    "law_sasser_flg" : "law_sasser_flg",
    "namehcr" : "namehcr",
    "rundate" : "rundate",
    "csa_flg" : 3,
    "cfpbeffdte" : "cfpbeffdte",
    "stcnty" : 0,
    "insfdic" : 2,
    "cbsa_div_flg" : 1,
    "chrtagnt" : "chrtagnt",
    "te01n529" : "te01n529",
    "conserve" : "conserve",
    "parcert" : 8,
    "csa" : "csa",
    "dateupdt" : "dateupdt",
    "cbsa_metro_name" : "cbsa_metro_name",
    "suprv_fd" : 6,
    "risdate" : "risdate",
    "sdi_data" : [ {
      "p9reres" : 4,
      "lnremult" : 8,
      "offdom" : 9,
      "lnrecnfm" : 1,
      "reportdate" : "reportdate",
      "lnre" : 3,
      "lnreres" : 9,
      "cert" : 8,
      "asset" : 0,
      "p3reres" : 5
    }, {
      "p9reres" : 4,
      "lnremult" : 8,
      "offdom" : 9,
      "lnrecnfm" : 1,
      "reportdate" : "reportdate",
      "lnre" : 3,
      "lnreres" : 9,
      "cert" : 8,
      "asset" : 0,
      "p3reres" : 5
    } ]
  },
  "meta" : {
    "type" : "type",
    "params" : {
      "id" : "id"
    }
  },
  "links" : {
    "self" : "self"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Banks
 * Returns a list of banks
 *
 * returns banks
 **/
exports.banksGET = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "data" : [ {
    "score" : 0,
    "address" : "address",
    "city" : "city",
    "cbsa_metro_name" : "cbsa_metro_name",
    "name" : "name",
    "links" : {
      "self" : "self"
    },
    "id" : "id",
    "type" : "type",
    "namehcr" : "namehcr"
  }, {
    "score" : 0,
    "address" : "address",
    "city" : "city",
    "cbsa_metro_name" : "cbsa_metro_name",
    "name" : "name",
    "links" : {
      "self" : "self"
    },
    "id" : "id",
    "type" : "type",
    "namehcr" : "namehcr"
  } ],
  "meta" : {
    "type" : "type",
    "params" : "{}"
  },
  "links" : {
    "self" : "self"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

