'use strict';

var utils = require('../utils/writer.js');
var Banks = require('../service/BanksService');

module.exports.banksBank_idGET = function banksBank_idGET (req, res, next) {
  var bank_id = req.swagger.params['bank_id'].value;
  Banks.banksBank_idGET(bank_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.banksGET = function banksGET (req, res, next) {
  Banks.banksGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
