# swagger_client.BanksApi

All URIs are relative to *https://atv1.cfapps.io/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**banks_bank_id_get**](BanksApi.md#banks_bank_id_get) | **GET** /banks/{bank_id} | Get Bank
[**banks_get**](BanksApi.md#banks_get) | **GET** /banks | Get Banks


# **banks_bank_id_get**
> Bank banks_bank_id_get(bank_id)

Get Bank

Returns an individual bank..

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.BanksApi()
bank_id = 56 # int | The unique id for the bank.

try:
    # Get Bank
    api_response = api_instance.banks_bank_id_get(bank_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BanksApi->banks_bank_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bank_id** | **int**| The unique id for the bank. | 

### Return type

[**Bank**](Bank.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **banks_get**
> Banks banks_get()

Get Banks

Returns a list of banks

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.BanksApi()

try:
    # Get Banks
    api_response = api_instance.banks_get()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BanksApi->banks_get: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Banks**](Banks.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

