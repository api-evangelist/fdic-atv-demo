# BanksLinks1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_self** | **str** | The Self Schema | [optional] [default to '']

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


