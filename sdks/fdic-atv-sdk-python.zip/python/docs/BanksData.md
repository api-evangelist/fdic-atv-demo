# BanksData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **str** | The Address Schema | [optional] [default to '']
**city** | **str** | The City Schema | [optional] [default to '']
**cbsa_metro_name** | **str** | The Cbsa_metro_name Schema | [optional] [default to '']
**name** | **str** | The Name Schema | [optional] [default to '']
**namehcr** | **str** | The Namehcr Schema | [optional] [default to '']
**score** | **int** | The Score Schema | [optional] 
**id** | **str** | The Id Schema | [optional] [default to '']
**type** | **str** | The Type Schema | [optional] [default to '']
**links** | [**BanksLinks1**](BanksLinks1.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


