# BankDataBranches

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offnum** | **int** | The Offnum Schema | [optional] 
**name** | **str** | The Name Schema | [optional] [default to '']
**offname** | **str** | The Offname Schema | [optional] [default to '']
**type** | **str** | The Type Schema | [optional] [default to '']

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


