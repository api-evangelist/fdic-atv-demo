# Banks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**BanksMeta**](BanksMeta.md) |  | [optional] 
**links** | [**BanksLinks**](BanksLinks.md) |  | [optional] 
**data** | [**list[BanksData]**](BanksData.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


