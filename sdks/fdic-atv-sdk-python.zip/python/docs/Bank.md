# Bank

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**BankMeta**](BankMeta.md) |  | [optional] 
**links** | [**BanksLinks1**](BanksLinks1.md) |  | [optional] 
**data** | [**BankData**](BankData.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


