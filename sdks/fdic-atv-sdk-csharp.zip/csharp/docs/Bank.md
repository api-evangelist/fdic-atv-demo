# IO.Swagger.Model.Bank
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Meta** | [**BankMeta**](BankMeta.md) |  | [optional] 
**Links** | [**BanksLinks1**](BanksLinks1.md) |  | [optional] 
**Data** | [**BankData**](BankData.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

