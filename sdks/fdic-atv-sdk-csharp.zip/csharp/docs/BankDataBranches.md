# IO.Swagger.Model.BankDataBranches
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Offnum** | **int?** | The Offnum Schema | [optional] 
**Name** | **string** | The Name Schema | [optional] [default to ""]
**Offname** | **string** | The Offname Schema | [optional] [default to ""]
**Type** | **string** | The Type Schema | [optional] [default to ""]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

