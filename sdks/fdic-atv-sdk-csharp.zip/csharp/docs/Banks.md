# IO.Swagger.Model.Banks
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Meta** | [**BanksMeta**](BanksMeta.md) |  | [optional] 
**Links** | [**BanksLinks**](BanksLinks.md) |  | [optional] 
**Data** | [**List&lt;BanksData&gt;**](BanksData.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

