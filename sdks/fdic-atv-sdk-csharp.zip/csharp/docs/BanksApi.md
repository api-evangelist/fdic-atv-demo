# IO.Swagger.Api.BanksApi

All URIs are relative to *https://atv1.cfapps.io/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**BanksBankIdGet**](BanksApi.md#banksbankidget) | **GET** /banks/{bank_id} | Get Bank
[**BanksGet**](BanksApi.md#banksget) | **GET** /banks | Get Banks


<a name="banksbankidget"></a>
# **BanksBankIdGet**
> Bank BanksBankIdGet (int? bankId)

Get Bank

Returns an individual bank..

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BanksBankIdGetExample
    {
        public void main()
        {
            var apiInstance = new BanksApi();
            var bankId = 56;  // int? | The unique id for the bank.

            try
            {
                // Get Bank
                Bank result = apiInstance.BanksBankIdGet(bankId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BanksApi.BanksBankIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bankId** | **int?**| The unique id for the bank. | 

### Return type

[**Bank**](Bank.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="banksget"></a>
# **BanksGet**
> Banks BanksGet ()

Get Banks

Returns a list of banks

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BanksGetExample
    {
        public void main()
        {
            var apiInstance = new BanksApi();

            try
            {
                // Get Banks
                Banks result = apiInstance.BanksGet();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BanksApi.BanksGet: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Banks**](Banks.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

