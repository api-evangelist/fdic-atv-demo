# IO.Swagger.Model.BankDataSdiData
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**P9reres** | **int?** | The P9reres Schema | [optional] 
**Lnremult** | **int?** | The Lnremult Schema | [optional] 
**Offdom** | **int?** | The Offdom Schema | [optional] 
**Lnrecnfm** | **int?** | The Lnrecnfm Schema | [optional] 
**Reportdate** | **string** | The Reportdate Schema | [optional] [default to ""]
**Lnre** | **int?** | The Lnre Schema | [optional] 
**Lnreres** | **int?** | The Lnreres Schema | [optional] 
**Cert** | **int?** | The Cert Schema | [optional] 
**Asset** | **int?** | The Asset Schema | [optional] 
**P3reres** | **int?** | The P3reres Schema | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

