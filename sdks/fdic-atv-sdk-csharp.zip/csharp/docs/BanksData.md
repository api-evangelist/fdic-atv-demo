# IO.Swagger.Model.BanksData
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address** | **string** | The Address Schema | [optional] [default to ""]
**City** | **string** | The City Schema | [optional] [default to ""]
**CbsaMetroName** | **string** | The Cbsa_metro_name Schema | [optional] [default to ""]
**Name** | **string** | The Name Schema | [optional] [default to ""]
**Namehcr** | **string** | The Namehcr Schema | [optional] [default to ""]
**Score** | **int?** | The Score Schema | [optional] 
**Id** | **string** | The Id Schema | [optional] [default to ""]
**Type** | **string** | The Type Schema | [optional] [default to ""]
**Links** | [**BanksLinks1**](BanksLinks1.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

