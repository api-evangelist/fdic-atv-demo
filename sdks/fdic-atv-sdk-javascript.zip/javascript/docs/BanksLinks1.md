# Atv1AppsApi.BanksLinks1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | **String** | The Self Schema | [optional] [default to &#39;&#39;]


