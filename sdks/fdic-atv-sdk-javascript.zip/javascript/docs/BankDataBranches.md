# Atv1AppsApi.BankDataBranches

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offnum** | **Number** | The Offnum Schema | [optional] 
**name** | **String** | The Name Schema | [optional] [default to &#39;&#39;]
**offname** | **String** | The Offname Schema | [optional] [default to &#39;&#39;]
**type** | **String** | The Type Schema | [optional] [default to &#39;&#39;]


