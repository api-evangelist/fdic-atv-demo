# Atv1AppsApi.BanksData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **String** | The Address Schema | [optional] [default to &#39;&#39;]
**city** | **String** | The City Schema | [optional] [default to &#39;&#39;]
**cbsaMetroName** | **String** | The Cbsa_metro_name Schema | [optional] [default to &#39;&#39;]
**name** | **String** | The Name Schema | [optional] [default to &#39;&#39;]
**namehcr** | **String** | The Namehcr Schema | [optional] [default to &#39;&#39;]
**score** | **Number** | The Score Schema | [optional] 
**id** | **String** | The Id Schema | [optional] [default to &#39;&#39;]
**type** | **String** | The Type Schema | [optional] [default to &#39;&#39;]
**links** | [**BanksLinks1**](BanksLinks1.md) |  | [optional] 


