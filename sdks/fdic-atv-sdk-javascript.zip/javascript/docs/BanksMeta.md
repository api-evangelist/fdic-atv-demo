# Atv1AppsApi.BanksMeta

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | The Type Schema | [optional] 
**params** | **Object** | The Type Schema | [optional] 


