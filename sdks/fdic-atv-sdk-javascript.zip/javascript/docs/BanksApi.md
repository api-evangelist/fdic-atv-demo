# Atv1AppsApi.BanksApi

All URIs are relative to *https://atv1.cfapps.io/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**banksBankIdGet**](BanksApi.md#banksBankIdGet) | **GET** /banks/{bank_id} | Get Bank
[**banksGet**](BanksApi.md#banksGet) | **GET** /banks | Get Banks


<a name="banksBankIdGet"></a>
# **banksBankIdGet**
> Bank banksBankIdGet(bankId)

Get Bank

Returns an individual bank..

### Example
```javascript
var Atv1AppsApi = require('atv1_apps_api');

var apiInstance = new Atv1AppsApi.BanksApi();

var bankId = 56; // Number | The unique id for the bank.


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.banksBankIdGet(bankId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bankId** | **Number**| The unique id for the bank. | 

### Return type

[**Bank**](Bank.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="banksGet"></a>
# **banksGet**
> Banks banksGet()

Get Banks

Returns a list of banks

### Example
```javascript
var Atv1AppsApi = require('atv1_apps_api');

var apiInstance = new Atv1AppsApi.BanksApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.banksGet(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Banks**](Banks.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

