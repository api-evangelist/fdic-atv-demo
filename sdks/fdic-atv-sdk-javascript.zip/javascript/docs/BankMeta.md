# Atv1AppsApi.BankMeta

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | The Type Schema | [optional] [default to &#39;&#39;]
**params** | [**BankMetaParams**](BankMetaParams.md) |  | [optional] 


