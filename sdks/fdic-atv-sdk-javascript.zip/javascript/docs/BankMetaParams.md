# Atv1AppsApi.BankMetaParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | An explanation about the purpose of this instance. | [optional] [default to &#39;&#39;]


