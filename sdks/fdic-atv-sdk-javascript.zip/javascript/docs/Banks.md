# Atv1AppsApi.Banks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**BanksMeta**](BanksMeta.md) |  | [optional] 
**links** | [**BanksLinks**](BanksLinks.md) |  | [optional] 
**data** | [**[BanksData]**](BanksData.md) |  | [optional] 


