# Atv1AppsApi.BankDataSdiData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**p9reres** | **Number** | The P9reres Schema | [optional] 
**lnremult** | **Number** | The Lnremult Schema | [optional] 
**offdom** | **Number** | The Offdom Schema | [optional] 
**lnrecnfm** | **Number** | The Lnrecnfm Schema | [optional] 
**reportdate** | **String** | The Reportdate Schema | [optional] [default to &#39;&#39;]
**lnre** | **Number** | The Lnre Schema | [optional] 
**lnreres** | **Number** | The Lnreres Schema | [optional] 
**cert** | **Number** | The Cert Schema | [optional] 
**asset** | **Number** | The Asset Schema | [optional] 
**p3reres** | **Number** | The P3reres Schema | [optional] 


